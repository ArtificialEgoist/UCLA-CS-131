(*
 * Based on code by Chris Stone and Steve Freund
 *)
 
module Expr2 = struct

  type t = float * float -> float

  (* the mathematical constant pi *)
  let pi = 4. *. atan 1.

  (* exprToString : t -> string *)
  let exprToString _ = "unknown"
    	
 end
